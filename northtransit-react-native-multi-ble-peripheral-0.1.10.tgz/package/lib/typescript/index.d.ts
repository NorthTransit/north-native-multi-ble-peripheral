import type { Buffer } from 'buffer';
import { EventEmitter } from 'eventemitter3';
export declare enum Permission {
    READABLE = 1,
    READ_ENCRYPTED,
    READ_ENCRYPTED_MITM,
    WRITEABLE,
    WRITE_ENCRYPTED,
    WRITE_ENCRYPTED_MITM,
    WRITE_SIGNED,
    WRITE_SIGNED_MITM
}
export declare enum Property {
    BROADCAST = 1,
    READ = 2,
    WRITE_NO_RESPONSE = 4,
    WRITE = 8,
    NOTIFY = 16,
    INDICATE = 32,
    SIGNED_WRITE = 64,
    EXTENDED_PROPS = 128
}
export declare enum TxPowerLevel {
    ULTRA_LOW = 0,
    LOW = 1,
    MEDIUM = 2,
    HIGH = 3
}
export declare enum AdvertiseMode {
    LOW_LATENCY = 0,
    LOW_POWER = 1,
    BALANCED = 2
}
export interface AdvertiseServices {
    [key: string]: Buffer;
}
export interface AdvertiseOptions {
    mode?: AdvertiseMode;
    txPowerLevel?: TxPowerLevel;
    connectable?: boolean;
    includeDeviceName?: boolean;
    includeTxPowerLevel?: boolean;
    manufacturerId?: number;
    manufacturerData?: Buffer;
}
export interface WriteEvent {
    serviceUuid: string;
    characteristicUuid: string;
    value: string;
}
export interface SubscriptionEvent {
    serviceUuid: string;
    characteristicUuid: string;
}
declare class Peripheral extends EventEmitter {
    private id;
    private _listeners?;
    private destroyed;
    constructor();
    static setDeviceName(name: string): Promise<any>;
    checkState(): Promise<string>;
    startAdvertising(servicesOrOpts?: AdvertiseServices | AdvertiseOptions, options?: AdvertiseOptions): Promise<any>;
    stopAdvertising(): Promise<any>;
    addService(uuid: string, primary: boolean): Promise<any>;
    addCharacteristic(serviceUuid: string, uuid: string, properties: Property, permissions: Permission): Promise<any>;
    updateValue(serviceUuid: string, characteristicUuid: string, value: Buffer): Promise<any>;
    sendNotification(serviceUuid: string, characteristicUuid: string, value: Buffer, isIndication?: boolean): Promise<any>;
    destroy(): Promise<any>;
}
export default Peripheral;
//# sourceMappingURL=index.d.ts.map